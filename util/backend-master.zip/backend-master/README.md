## Criação de uma estrutura Backend PHP, no Paradigma Funcional

#### Desenvolvimento:
1- Document Root;
2- Rotas com url amigáveis;
3- Templates das Requisições;
4- Quebrando as responsabilidades;
5- Tratamento de Erros;
6- Configuração Geral;
7- Ajustando Status Code da aplicação;
8- Inserindo Framework Bootstrap 4.5;
9- Implementando Flash Messages com PNotify;
10- Pages criadas na Base de Dados;
11- Implementando Usuarios;
12- Implementando Autenticação;