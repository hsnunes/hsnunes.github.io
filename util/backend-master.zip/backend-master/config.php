<?php

define('DEBUG', true);
define('DB_SERVER', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'dbmysql');

// echo "echo `create database dbmysql` | mysql -u root -p ... Para criar o banco e remover o erro";