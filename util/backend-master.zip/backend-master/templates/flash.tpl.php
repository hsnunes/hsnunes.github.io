new PNotify({
    title: '<?php echo $data['type']; ?>',
    text: '<?php echo $data['message']; ?>',
    type: '<?php echo $data['type']; ?>'
});